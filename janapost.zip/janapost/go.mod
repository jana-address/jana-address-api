module janapost

go 1.21
