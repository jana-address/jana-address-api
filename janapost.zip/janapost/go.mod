module janapost

go 1.22
