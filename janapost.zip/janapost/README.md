# Jańa Post — главная страница на Go

    cd janapost
    go run .          # http://localhost:8080

Шаблоны и статика вшиваются в бинарник через `go:embed`.
