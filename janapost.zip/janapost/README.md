# Jańa Post

    go run .            # http://localhost:8080
    PORT=3000 go run .  # другой порт

Структура: main.go, go.mod, templates/{index,stub}.html, static/{style.css,app.js}
